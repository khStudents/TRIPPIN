/**
 * 
 */

       $(function() {
                $( ".datepicker" ).datepicker({
                dateFormat: 'yy-mm-dd'
           });
    });
       
       
       window.onload = function(){
           var width = screen.availWidth-20;
           var height = screen.availHeight;
           var body = document.getElementById("body");
           var make_intro = document.getElementById("make_intro");
           body.style.width = width+"px";
           make_intro.style.width = width+"px";
           body.style.height = height+"px";
           make_intro.style.height = height+"px";
           console.log(width+","+height);  
           
           
           $("#make_btn").click(function () {
               $("#make_intro").show();
           });
             
        $("#close_intro").click(function () {
               $("#make_intro").hide();
           });
           
           
           $("#main_start").change(function(){
        	  
        		  $("#intro_start").val($(this).val()); 
        	   });
           
           $("#intro_start").change(function(){
        	  
        		  $("#main_start").val($(this).val()); 
        	   });
           
       };
       
      
          
       
       
       var content_map = document.getElementById("main_map");

   ;
   var count =0; 

   function check(a){
       var c = document.getElementById("string"+a).innerHTML;
       
       $("#select_list2").append('<div class=list_div id=list_sub'+count+' >'+c+'<button style=float:left; onclick=remove('+count+')>x</button></div>');
             $("#list2").show();
             $("#make_btn").show();
             count++;
   }
   
   function remove(a){
	   var c = document.getElementById("list_sub"+a);
	   c.remove();
   }
   
 
   
   
         
         
         
         
         